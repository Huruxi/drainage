import request from '../utils/request';


let host = 'http://120.48.31.250/api';
//  let host = 'http://localhost:8088/api';

/**
 *  创建激活码
 * @param {*} query 
 */
export const createActiveCode = query => {
    return request({
        url: host + '/ac/createActiveCode',
        method: 'post',
        params: query
    });
};

/**
 *  获取激活码列表
 * @param {*} query 
 */
export const findActiveCodes = query => {
    return request({
        url: host + '/ac/findActiveCodes',
        method: 'post',
        params: query
    });
};

/**
 *  搜索激活码
 * @param {*} query 
 */
export const searchActiveCodes = query => {
    return request({
        url: host + '/ac/searchActiveCodes',
        method: 'post',
        params: query
    });
};

/**
 *  删除激活码
 * @param {*} query 
 */
export const delActiveCode = query => {
    return request({
        url: host + '/ac/delActiveCode',
        method: 'post',
        params: query
    });
};


