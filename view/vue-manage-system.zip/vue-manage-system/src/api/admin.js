import request from '../utils/request';

let host = 'http://120.48.31.250/api';
// let host = 'http://localhost:8088/api';

/**
 * 登录用户
 * @param {} query 
 */
export const loginUser = query => {
    return request({
        url: host + '/admin/0/loginUser',
        method: 'post',
        params: query
    });
};


/**
 * 添加管理员
 * @param {} query 
 */
export const addAdmin = query => {
    return request({
        url: host +  '/admin/addAdmin',
        method: 'post',
        params: query
    });
};

/**
 * 退出登录
 * @param {} query 
 */
export const outLogin = query => {
    return request({
        url: host + '/admin/outLogin',
        method: 'post',
        params: query
    });
};




