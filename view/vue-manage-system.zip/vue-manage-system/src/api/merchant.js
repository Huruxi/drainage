import request from '../utils/request';
import axios from 'axios';

let host = 'http://120.48.31.250/api';
// let host = 'http://localhost:8088/api';


//updatePlacard
export const updatePlacard = query => {
    return axios.post(
        host + '/merchant/updatePlacard', 
        {
            id:query.id,
            title:query.title,
            content:query.content,
            isRelease:query.isRelease ? 1 : 0
        }
    );
};

export const findNewPlacard = query => {
    return request({
        url: host + '/merchant/findNewPlacard',
        method: 'post',
        params: query
    });
};

export const findMerchantInfo = query => {
    return request({
        url: host + '/merchant/0/findMerchantInfo',
        method: 'post',
        params: query
    });
};

export const updateMerchantInfo = query => {
    // return request({
    //     url: host + '/merchant/updateMerchantInfo',
    //     method: 'post',
    //     params: query
    // });

    return axios.post(
        host + '/merchant/updateMerchantInfo', 
        query
    );
};


export const findMerchantAccounts = query => {
    return request({
        url: host + '/merchant/findMerchantAccounts',
        method: 'post',
        params: query
    });
};

export const updateMerchantAccount = query => {
    return request({
        url: host + '/merchant/updateMerchantAccount',
        method: 'post',
        params: query
    });
};

export const delMerchantAccount = query => {
    return request({
        url: host + '/merchant/delMerchantAccount',
        method: 'post',
        params: query
    });
};



