import request from '../utils/request';

let host = 'http://120.48.31.250/api';
// let host = 'http://localhost:8088/api';

export const findRebateForm = query => {
    return request({
        url: host + '/rebate/findRebateForm',
        method: 'post',
        params: query
    });
};

export const searchRebateForm = query => {
    return request({
        url: host + '/rebate/0/searchRebateForm',
        method: 'post',
        params: query
    });
};

export const rebateIncome = query => {
    return request({
        url: host + '/statistic/findDailyActiveCodeRebateIncome',
        method: 'post',
        params: query
    });
};

export const activeCodeSellIncome = query => {
    return request({
        url: host + '/statistic/findDailyActiveCodeSellIncome',
        method: 'post',
        params: query
    });
};

export const statisticsActiveCodeRebate = query => {
    return request({
        url: host + '/statistic/statisticsActiveCodeRebate',
        method: 'post',
        params: query
    });
};