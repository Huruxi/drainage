<template>
    <div>
        <div class="crumbs">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item>
                    <i class="el-icon-lx-calendar"></i> 激活码
                </el-breadcrumb-item>
                <el-breadcrumb-item>生成激活码</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div class="container">
            <div class="handle-box">
                <el-input v-model="query.code" placeholder="激活码" class="handle-input mr10"></el-input>
                <el-select v-model="query.typeId" placeholder="请选择激活码类型" class="mr10">
                    <el-option key="-1" label="全部" value="-1"></el-option>
                    <el-option key="1" label="100月卡" value="1"></el-option>
                    <el-option key="2" label="1000月卡" value="2"></el-option>
                    <el-option key="3" label="5000月卡" value="3"></el-option>
                </el-select>
                <el-select v-model="query.loginState" placeholder="请选择在线状态" class="mr10">
                    <el-option key="-1" label="全部" value="-1"></el-option>
                    <el-option key="1" label="在线" value="1"></el-option>
                    <el-option key="0" label="离线" value="0"></el-option>
                </el-select>
                <el-button type="primary" icon="el-icon-search" @click="handleSearch">搜索</el-button>

                <el-button type="primary" @click="drawer = true">生成激活码</el-button>
            </div>

            <el-table
                :data="tableData"
                border
                class="table"
                ref="multipleTable"
                header-cell-class-name="table-header"
                @selection-change="handleSelectionChange"
            >
                <el-table-column type="selection" width="55" align="center"></el-table-column>
                <el-table-column prop="id" label="ID" width="55" align="center"></el-table-column>
                <el-table-column prop="code" label="激活码"></el-table-column>
                <el-table-column label="激活码类型">
                    <template slot-scope="scope">
                        <el-tag>{{scope.row.typeId === 1 ? '100月卡' : scope.row.typeId === 2 ? '1000月卡' : scope.row.typeId === 3 ? '5000月卡':''}}</el-tag>
                    </template>
                </el-table-column>

                <el-table-column label="激活状态" align="center">
                    <template slot-scope="scope">
                        <el-tag
                            :type="scope.row.status === 1 ? 'success':(scope.row.status ===0 ? 'danger':'')"
                        >{{scope.row.status === 1 ? '激活' : '未激活'}}</el-tag>
                    </template>
                </el-table-column>

                <el-table-column label="在线状态" align="center">
                    <template slot-scope="scope">
                        <el-tag :type="scope.row.loginState === 1 ? 'success':(scope.row.loginState === 0 ? 'danger':'')"
                        >{{scope.row.loginState === 1 ? '在线' : '离线'}}</el-tag>
                    </template>
                </el-table-column>

                <el-table-column prop="updateTime" label="在线时长">
                    <template slot-scope="scope">
                        <el-tag>{{countLoginDuration(scope.row)}}</el-tag>
                    </template>
                </el-table-column>
                <el-table-column label="生成时间" align="center">
                    <template slot-scope="scope">
                        <el-tag>{{dealWithTime(new Date(scope.row.addTime))}}</el-tag>
                    </template>
                </el-table-column>

                <el-table-column label="操作" width="180" align="center">
                    <template slot-scope="scope">
                        <el-button
                            type="text"
                            icon="el-icon-delete"
                            class="red"
                            @click="handleDelete(scope.$index, scope.row)"
                        >删除</el-button>
                    </template>
                </el-table-column>
            </el-table>

            <div class="pagination">
                <el-pagination
                    background
                    layout="total, prev, pager, next"
                    :current-page="query.pageIndex"
                    :page-size="query.pageSize"
                    :total="pageTotal"
                    @current-change="handlePageChange"
                ></el-pagination>
            </div>
        </div>

        <el-dialog
            title="激活码"
            :visible.sync="dialogVisible"
            width="30%"
            >
            <span>{{form.desc}}</span>
            <span slot="footer" class="dialog-footer">
                <!-- <el-button @click="dialogVisible = false">取 消</el-button> -->
                <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
            </span>
        </el-dialog>

        
         <el-drawer
            title="生成激活码"
            :visible.sync="drawer"
            :direction="direction"
            >
            <el-radio-group v-model="typeid">
                <el-radio :label="1">100月卡</el-radio>
                <el-radio :label="2">1000月卡</el-radio>
                <el-radio :label="3">5000月卡</el-radio>
            </el-radio-group>
            
            <el-button  type="primary" style="margin-left: 16px;" @click="generateActivationCode()">
                生成
            </el-button>
        </el-drawer>
    </div>
</template>

<script>
import { createActiveCode,findActiveCodes,searchActiveCodes,delActiveCode } from '../../api/activeCode';
export default {
    name: 'basetable',
    data() {
        return {
            drawer: false,
            direction: 'btt',
            typeid: 3,
            query: {
                typeId: '',
                loginState: '',
                code: '',
                pageIndex: 1,
                pageSize: 10
            },
            tableData: [],
            multipleSelection: [],
            delList: [],
            editVisible: false,
            pageTotal: 0,
            form: {desc:''},
            idx: -1,
            id: -1,
            dialogVisible: false
        };
    },
    created() {
        this.getData();
    },
    methods: {

         generateActivationCode(){
             createActiveCode({typeId:this.typeid}).then(res => {
                if(res.code == 200){
                    this.form.desc = res.data.code
                    this.$alert(res.data.code, '激活码为：', {
                        confirmButtonText: '确定'
                    });   
                    this.getData();
                }else{
                    this.$message.error('生成激活码失败');
                }
            });
            // this.form.desc = this.randomWord(false,132);
            // this.dialogVisible = true;
         },

         dealWithTime(date) {
            let Y = date.getFullYear()
            let M = date.getMonth() + 1 - 0 >= 10 ? Number(date.getMonth()) + 1 : '0' + (Number(date.getMonth()) + 1)
            let D = date.getDate()
            let h = date.getHours() >= 10 ? date.getHours() : '0' + date.getHours()
            let m = date.getMinutes() >= 10 ? date.getMinutes() : '0' + date.getMinutes()
            let s = date.getSeconds() >= 10 ? date.getSeconds() : '0' + date.getSeconds()
            return Y + '-' + M + '-' + D + ' ' + h + ':' + m + ':' + s
        },
        
        countLoginDuration(row){
            if(row.loginState == 1){
                let loginTime = new Date().getTime() - new Date(row.updateTime).getTime();
                let d = this.countDate(loginTime);
                return d.hours + ":" + d.minutes + ":" + d.seconds;
            }
            return 0;
        },

        countDate(time){
            let hours,minutes,seconds;
            //计算出小时数
            let leave1 = time % (3600 * 24 * 1000);//计算天数后剩余的毫秒数
            hours = this.checkTime(Math.floor(leave1 / (3600 * 1000)));

            //计算相差分钟数
            let leave2 = leave1 % (3600 * 1000);//计算小时数后剩余的毫秒数
            minutes = this.checkTime(Math.floor(leave2 / (60 * 1000)));

            //计算相差秒数
            let leave3 = leave2 % (60 * 1000);//计算分钟数后剩余的毫秒数
            seconds = this.checkTime(Math.round(leave3 / 1000));

            return {
                'hours':hours,
                'minutes':minutes,
                'seconds':seconds
            };
        },

        checkTime(i){//如果结果为个位数，则在前面补零
            if (i<10)
            {
                i="0" + i
            }
            return i
        },
        
        randomWord(randomFlag, min, max){
            let str='', range=min,
            arr= ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 
            'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l',
            'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 
            'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 
            'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];

            //随机位数
            if(randomFlag){
                range=Math.round(Math.random()*(max-min))+min;
            }
            //每位随机字符 
            for(let i=0;i<range;i++){
                let pos=Math.round(Math.random()*(arr.length-1));
                str += arr[pos];
            }
            return str;
        },

        // 获取 easy-mock 的模拟数据
        getData() {
            this.getActiveCodes(); 
            // let param = {
            //     sortType : 0,
            //     offset: this.query.pageIndex,
            //     limit: this.query.pageSize
            // };

            // findActiveCodes(param).then(res => {
            //     if(res.code == 200){
            //         this.tableData = res.data.records;
            //         this.pageTotal = res.data.total;
            //     }
            // });
        },
        // 触发搜索按钮
        handleSearch() {
           this.getActiveCodes();            
        },

        getActiveCodes(){
            let param = {
                code: this.query.code,
                typeId:this.query.typeId == -1 ? '' : this.query.typeId,
                loginState:this.query.loginState == -1 ? '' : this.query.loginState,
                offset: this.query.pageIndex,
                limit: this.query.pageSize
            };

            searchActiveCodes(param).then(res => {
                if(res.code == 200){
                    this.tableData = res.data.records;
                    this.pageTotal = res.data.total;
                }else{
                    this.$message.error(res.message);        
                }
            });
        },

        // 删除操作
        handleDelete(index, row) {
            // 二次确认删除
            this.$confirm('确定要删除吗？', '提示', {
                type: 'warning'
            })
                .then(() => {
                    delActiveCode({id: row.id}).then(res => {
                            if(res.code == 200){
                                this.$message.success('删除成功');
                                this.tableData.splice(index, 1);
                            }else{
                                this.$message.success('删除成功'); 
                            }
                        });
                })
                .catch(() => {});
        },
        // 多选操作
        handleSelectionChange(val) {
            this.multipleSelection = val;
        },
        delAllSelection() {
            const length = this.multipleSelection.length;
            let str = '';
            this.delList = this.delList.concat(this.multipleSelection);
            for (let i = 0; i < length; i++) {
                str += this.multipleSelection[i].name + ' ';
            }
            this.$message.error(`删除了${str}`);
            this.multipleSelection = [];
        },
        // 编辑操作
        handleEdit(index, row) {
            this.idx = index;
            this.form = row;
            this.editVisible = true;
        },
        // 保存编辑
        saveEdit() {
            this.editVisible = false;
            this.$message.success(`修改第 ${this.idx + 1} 行成功`);
            this.$set(this.tableData, this.idx, this.form);
        },
        // 分页导航
        handlePageChange(val) {
            console.log(val);
            this.$set(this.query, 'pageIndex', val);
            this.getData();
        }
    }
};
</script>


<style scoped>
.handle-box {
    margin-bottom: 20px;
}

.handle-select {
    width: 120px;
}

.handle-input {
    width: 300px;
    display: inline-block;
}
.table {
    width: 100%;
    font-size: 14px;
}
.red {
    color: #ff0000;
}
.mr10 {
    margin-right: 10px;
}
.table-td-thumb {
    display: block;
    margin: auto;
    width: 40px;
    height: 40px;
}
</style>
