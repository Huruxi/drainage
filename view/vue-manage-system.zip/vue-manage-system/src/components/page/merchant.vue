<template>
    <div>
        <div class="crumbs">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item>
                    <i class="el-icon-lx-calendar"></i> 商户账户信息
                </el-breadcrumb-item>
                <!-- <el-breadcrumb-item>基本表单</el-breadcrumb-item> -->
            </el-breadcrumb>
        </div>

        <div class="container">
            <div class="handle-box">
                <el-input v-model="query.name" placeholder="搜索名称关键字" class="handle-input mr10"></el-input>
                <el-button type="primary" icon="el-icon-search" @click="searchData">搜索</el-button>
            </div>

            <el-table
                :data="tableData"
                border
                class="table"
                ref="multipleTable"
                header-cell-class-name="table-header"
                @selection-change="handleSelectionChange"
            >
                <el-table-column type="selection" width="55" align="center"></el-table-column>
                <el-table-column prop="id" label="ID" width="55" align="center"></el-table-column>
                <el-table-column prop="name" label="名称"></el-table-column>
                <el-table-column prop="mobile" label="号码"></el-table-column>
                <el-table-column prop="accountNumber" label="账号"></el-table-column>
                <el-table-column label="支付方式">
                    <template slot-scope="scope">{{scope.row.payType == 1 ? '微信' : scope.row.payType == 2 ? '支付宝': scope.row.payType == 3 ? '银行卡':'其它'}}</template>
                </el-table-column>

                <el-table-column label="支付状态" align="center">
                    <template slot-scope="scope" :type="scope.row.payStatus === 1 ? 'success': (scope.row.payStatus === 0 ? 'danger':'')">
                        <el-tag>{{scope.row.payStatus == 0 ? '未支付' : scope.row.payStatus == 1 ? '已支付': ''}}</el-tag>
                    </template>
                </el-table-column>

                <el-table-column label="添加时间" align="center">
                    <template slot-scope="scope">
                        <el-tag>{{dealWithTime(new Date(scope.row.addTime))}}</el-tag>
                    </template>
                </el-table-column>

                <el-table-column label="操作" width="180" align="center">
                    <template slot-scope="scope">
                        <el-button
                            type="text"
                            icon="el-icon-edit"
                            @click="handleEdit(scope.$index, scope.row)"
                        >编辑</el-button>
                        <el-button
                            type="text"
                            icon="el-icon-delete"
                            class="red"
                            @click="handleDelete(scope.$index, scope.row)"
                        >删除</el-button>
                    </template>
                </el-table-column>
            </el-table>

            <div class="pagination">
                <el-pagination
                    background
                    layout="total, prev, pager, next"
                    :current-page="query.pageIndex"
                    :page-size="query.pageSize"
                    :total="pageTotal"
                    @current-change="handlePageChange"
                ></el-pagination>
            </div>
        </div>  

         <!-- 编辑弹出框 -->
        <el-dialog title="编辑" :visible.sync="editVisible" width="30%">
            <el-form ref="form" :model="form" label-width="70px">
                <el-form-item label="用户名称">
                    <el-input v-model="form.name" disabled="true"></el-input>
                </el-form-item>
                <el-form-item label="支付状态">
                    <el-select v-model="form.payStatus" placeholder="请选择支付状态">
                        <el-option key="1" label="已支付" value="1"></el-option>
                        <el-option key="0" label="未支付" value="0"></el-option>
                    </el-select>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="editVisible = false">取 消</el-button>
                <el-button type="primary" @click="saveEdit">确 定</el-button>
            </span>
        </el-dialog>      
    </div>    
</template>

<script>
import { findMerchantAccounts,updateMerchantAccount,delMerchantAccount } from '../../api/merchant';
export default {
    data(){
        return {
            query:{
                name:'',
                pageIndex: 1,
                pageSize: 10
            },
            form: {
                id: 0,
                name: '',
                val: '',
            },
            multipleSelection: [],
            tableData: [],
            pageTotal: 0,
            editVisible: false,            
        }
    },
    computed:{
       
    },
    created() {
        this.getData();
    },
    
    methods: {
         getData() {
             this.getMerchantAccounts();
         },

        getMerchantAccounts(){
            findMerchantAccounts(this.query).then(res => {
                 if(res.code == 200){
                     if(res.data){
                        this.tableData = res.data.records;
                        this.pageTotal = res.data.total;
                     }
                }
            });     
        },

        searchData(){
            this.getMerchantAccounts();
        },

        merchantInfoHandle(){
            if(!this.form.name){
                this.$message.success('请输入银行名称');
                return;      
            }
            if(!this.form.val){
                this.$message.success('请输入银行卡号');
                return;      
            }

            updateMerchantInfo(this.form).then(res => {
                if(res.code == 200){
                    this.$message.success('操作成功');
                }else{
                    this.$message.error('操作失败');
                }
            });  
        },

         // 多选操作
        handleSelectionChange(val) {
            this.multipleSelection = val;
        },

        handlePageChange(val){
            this.$set(this.query, 'pageIndex', val);
            this.getData();
        },

        dealWithTime(date) {
            let Y = date.getFullYear()
            let M = date.getMonth() + 1 - 0 >= 10 ? Number(date.getMonth()) + 1 : '0' + (Number(date.getMonth()) + 1)
            let D = date.getDate()
            let h = date.getHours() >= 10 ? date.getHours() : '0' + date.getHours()
            let m = date.getMinutes() >= 10 ? date.getMinutes() : '0' + date.getMinutes()
            let s = date.getSeconds() >= 10 ? date.getSeconds() : '0' + date.getSeconds()
            return Y + '-' + M + '-' + D + ' ' + h + ':' + m + ':' + s
        },

        // 编辑操作
        handleEdit(index, row) {
            this.idx = index;
            this.form = row;
            this.form.payStatus = '' + row.payStatus;
            this.editVisible = true;
        },

        // 删除操作
        handleDelete(index, row) {
            // 二次确认删除
            this.$confirm('确定要删除吗？', '提示', {
                type: 'warning'
            }).then(() => {
                delMerchantAccount({id:row.id}).then(res => {
                    if(res.code == 200){
                         this.$message.success('删除成功');
                         this.tableData.splice(index, 1);
                    }else{
                        this.$message.error(res.message);    
                    }
                });       
            }).catch(() => {});
        },
         // 保存编辑
        saveEdit() {
            this.editVisible = false;
            let param = {
                id: this.form.id,
                payStatus: this.form.payStatus,
            };
            updateMerchantAccount(param).then(res => {
                 if(res.code == 200){
                     this.$message.success(`修改第 ${this.idx + 1} 行成功`);
                }else{
                    this.$message.error(res.message);    
                }
            });       
        },
    }
}
</script>


<style scoped>
.handle-box {
    margin-bottom: 20px;
}

.handle-select {
    width: 120px;
}

.handle-input {
    width: 300px;
    display: inline-block;
}
.table {
    width: 100%;
    font-size: 14px;
}
.red {
    color: #ff0000;
}
.mr10 {
    margin-right: 10px;
}
.table-td-thumb {
    display: block;
    margin: auto;
    width: 40px;
    height: 40px;
}
</style>
