<template>
    <div>
        <div class="crumbs">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item>
                    <i class="el-icon-lx-calendar"></i> 公告
                </el-breadcrumb-item>
                <!-- <el-breadcrumb-item>基本表单</el-breadcrumb-item> -->
            </el-breadcrumb>
        </div>

        <div class="container">
            <div>
                <el-form ref="form" :model="form" label-width="80px">
                     <el-form-item label="公告标题">
                        <el-input v-model="form.title" placeholder="请输入公告标题"></el-input>
                    </el-form-item>

                    <el-form-item label="公告内容">
                        <!-- <el-input type="textarea" rows="5" v-model="form.content"></el-input> -->
                        <quill-editor ref="myTextEditor" v-model="form.content" :options="editorOption"></quill-editor>
                    </el-form-item>
                    <el-form-item label="是否发布">
                        <el-switch v-model="form.isRelease"></el-switch>
                    </el-form-item>
                    <el-form-item>
                        <el-button type="primary" @click="placardDataHandle">提交</el-button>
                        <!-- <el-button>取消</el-button> -->
                    </el-form-item>
                </el-form>            
            </div>
        </div>        
    </div>    
</template>

<script>
import 'quill/dist/quill.core.css';
import 'quill/dist/quill.snow.css';
import 'quill/dist/quill.bubble.css';
import { quillEditor } from 'vue-quill-editor';

import { findNewPlacard,updatePlacard } from '../../api/merchant';
export default {
    data(){
        return {
            query:{
            },
            form: {
                id: 0,
                title: '',
                content: '',
                isRelease: true
            },
            content: '',
            editorOption: {
                placeholder: '在此录入公告'
            }
        }
    },
    computed:{
       
    },
    
    components: {
        quillEditor
    },

    created() {
        this.getData();
    },
    
    methods: {
         getData() {
             this.findPlacard();
         },

        findPlacard(){
            findNewPlacard({}).then(res => {
                 if(res.code == 200){
                    this.form = res.data;
                    this.form.isRelease = res.data.isRelease === 1 ? true : false;
                }
            });     
        },

        placardDataHandle(){
            if(!this.form.title){
                this.$message.success('请输入公告标题');
                return;      
            }
            if(!this.form.content){
                this.$message.success('请输入公告内容');
                return;      
            }

            updatePlacard(this.form).then(res => {
                 res = res.data;
                 if(res.code == 200){
                    this.$message.success('操作成功');
                }else{
                    this.$message.error('操作失败');
                }
            });  
        },

        onEditorChange({ editor, html, text }) {
                this.content = html;
        },

        submit(){
            console.log(this.content);
            this.$message.success('提交成功！');
        }
    }
}
</script>

<style scoped>
    .editor-btn{
        margin-top: 20px;
    }
</style>