<template>
    <div>
        <div class="crumbs">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item>
                    <i class="el-icon-lx-calendar"></i> 每日统计
                </el-breadcrumb-item>
                <!-- <el-breadcrumb-item>统计</el-breadcrumb-item> -->
            </el-breadcrumb>
        </div>
        <div class="container">
            <el-tabs v-model="message">
                <el-tab-pane :label="`激活码激活统计`" name="first">
                     <el-table
                        :data="activeCodeData"
                        border
                        class="table"
                        ref="multipleTable"
                        header-cell-class-name="table-header"
                        @selection-change="handleSelectionChange"
                    >
                        <el-table-column type="selection" width="55" align="center"></el-table-column>
                        <el-table-column label="激活码类型">
                            <template slot-scope="scope">
                                <el-tag>{{scope.row.typeId === 1 ? '100月卡' : scope.row.typeId === 2 ? '1000月卡' : scope.row.typeId === 3 ? '5000月卡':''}}</el-tag>
                            </template>
                        </el-table-column>
                        <el-table-column prop="num" label="数量"></el-table-column>
                        <el-table-column label="时间" align="center">
                            <template slot-scope="scope">
                                <el-tag>{{dealWithTime(new Date(scope.row.addTime))}}</el-tag>
                            </template>
                        </el-table-column>
                    </el-table>

                    <div class="pagination">
                        <el-pagination
                            background
                            layout="total, prev, pager, next"
                            :current-page="activeCodeQuery.pageIndex"
                            :page-size="activeCodeQuery.pageSize"
                            :total="activeCodeTotal"
                            @current-change="activeCodeChange"
                        ></el-pagination>
                    </div>
                </el-tab-pane>


               <el-tab-pane :label="`激活码每日返利统计`" name="second">
                    <template v-if="message === 'second'">
                       <el-table
                            :data="tableData"
                            border
                            class="table"
                            ref="multipleTable"
                            header-cell-class-name="table-header"
                            @selection-change="handleSelectionChange"
                        >
                            <el-table-column type="selection" width="55" align="center"></el-table-column>
                            <el-table-column prop="code" label="激活码"></el-table-column>
                            <el-table-column prop="money" label="金额"></el-table-column>
                            <el-table-column label="时间" align="center">
                                <template slot-scope="scope">
                                    <el-tag>{{dealWithTime(new Date(scope.row.addTime))}}</el-tag>
                                </template>
                            </el-table-column>
                        </el-table>

                        <div class="pagination">
                            <el-pagination
                                background
                                layout="total, prev, pager, next"
                                :current-page="query.pageIndex"
                                :page-size="query.pageSize"
                                :total="pageTotal"
                                @current-change="handlePageChange"
                            ></el-pagination>
                        </div>
                    </template>
                </el-tab-pane> 

                 <el-tab-pane :label="`激活码总返利统计`" name="second2">
                    <template v-if="message === 'second2'">
                        <div class="handle-box form-box flexbox">
                            <div   class="mr10 flex">
                                <el-input v-model="activeCodeRebateQuery.code" placeholder="搜索激活码关键字" class="handle-input"></el-input>
                            </div>
                            <div  class="mr10 flex">
                                    <el-date-picker
                                        type="date"
                                        placeholder="选择开始日期"
                                        v-model="activeCodeRebateQuery.startTime"
                                        value-format="yyyy-MM-dd"
                                        style="width: 100%;"
                                    ></el-date-picker>
                            </div>
                            <div  class="mr10 flex">       
                                    <el-date-picker
                                        type="date"
                                        placeholder="选择结束日期"
                                        v-model="activeCodeRebateQuery.endTime"
                                        value-format="yyyy-MM-dd"
                                        style="width: 100%;"
                                    ></el-date-picker>
                            </div>
                            <div class="mr10 flex"> 
                                <el-button type="primary" icon="el-icon-search" @click="searchActiveCodeRebateQuery">搜索</el-button>
                            </div>
                        </div>
                        
                       <el-table
                            :data="activeCodeRebateData"
                            border
                            class="table"
                            ref="multipleTable"
                            header-cell-class-name="table-header"
                            @selection-change="handleSelectionChange"
                        >
                            <el-table-column type="selection" width="55" align="center"></el-table-column>
                            <el-table-column prop="code" label="激活码"></el-table-column>
                            <el-table-column prop="money" label="金额"></el-table-column>
                            <!-- <el-table-column label="时间" align="center">
                                <template slot-scope="scope">
                                    <el-tag>{{dealWithTime(new Date(scope.row.addTime))}}</el-tag>
                                </template>
                            </el-table-column> -->
                        </el-table>

                        <div class="pagination">
                            <el-pagination
                                background
                                layout="total, prev, pager, next"
                                :current-page="activeCodeRebateQuery.pageIndex"
                                :page-size="activeCodeRebateQuery.pageSize"
                                :total="activeCodeRebateTotal"
                                @current-change="activeCodeRebateChange"
                            ></el-pagination>
                        </div>
                    </template>
                </el-tab-pane>
            </el-tabs>
        </div>
    </div>
</template>

<script> 
import { activeCodeSellIncome,rebateIncome,statisticsActiveCodeRebate } from '../../api/rebate';
export default {
    name: 'basetable',
    data() {
        return {
            message: 'first',
            query: {
                code: '',
                pageIndex: 1,
                pageSize: 10
            },
            tableData: [],
            multipleSelection: [],
            delList: [],
            editVisible: false,
            pageTotal: 0,
            form: {desc:''},
            idx: -1,
            id: -1,
            dialogVisible: false,
            activeCodeQuery: {
                pageIndex: 1,
                pageSize: 10
            },
            activeCodeData: [],
            activeCodeTotal: 0,
            activeCodeRebateQuery: {
                code: '',
                startTime: '',
                endTime: '',
                pageIndex: 1,
                pageSize: 10
            },
            activeCodeRebateData: [],
            activeCodeRebateTotal: 0,

        };
    },
    created() {
        this.getData();
    },
    methods: {

         statisticRebateIncome(){
             rebateIncome(this.query).then(res => {
                 if(res.code == 200){
                    this.tableData = res.data.records;
                    this.pageTotal = res.data.total;
                }
            });
            
         },

        statisticActiveCodeSellIncome(){
            activeCodeSellIncome(this.activeCodeQuery).then(res => {
                 if(res.code == 200){
                    this.activeCodeData = res.data.records;
                    this.activeCodeTotal = res.data.total;
                }
            });
        },         

        statisticsActiveCodeRebateList(){
            statisticsActiveCodeRebate(this.activeCodeRebateQuery).then(res => {
                 if(res.code == 200){
                    this.activeCodeRebateData = res.data.records;
                    this.activeCodeRebateTotal = res.data.total;
                }
            });
        },         
         
        // 获取 easy-mock 的模拟数据
        getData() {
            this.statisticRebateIncome();
            this.statisticActiveCodeSellIncome();
            this.statisticsActiveCodeRebateList();
        },

        searchActiveCodeRebateQuery(){
            this.statisticsActiveCodeRebateList();
        },

        dealWithTime(date) {
            let Y = date.getFullYear()
            let M = date.getMonth() + 1 - 0 >= 10 ? Number(date.getMonth()) + 1 : '0' + (Number(date.getMonth()) + 1)
            let D = date.getDate()
            // let h = date.getHours() >= 10 ? date.getHours() : '0' + date.getHours()
            // let m = date.getMinutes() >= 10 ? date.getMinutes() : '0' + date.getMinutes()
            // let s = date.getSeconds() >= 10 ? date.getSeconds() : '0' + date.getSeconds()
            // return Y + '-' + M + '-' + D + ' ' + h + ':' + m + ':' + s
            return Y + '-' + M + '-' + D;
        },

        // 触发搜索按钮
        handleSearch() {
            if(!this.query.code){
                this.$message.success('请输入激活码');
                return;
            }
            searchActiveCodes({code: this.query.code}).then(res => {
                if(res.code == 200){
                    this.tableData = [res.data];
                    this.pageTotal = this.tableData.length;
                }else{

                }
            });
        },
        // 删除操作
        handleDelete(index, row) {
            // 二次确认删除
            this.$confirm('确定要删除吗？', '提示', {
                type: 'warning'
            })
                .then(() => {
                    this.$message.success('删除成功');
                    this.tableData.splice(index, 1);
                })
                .catch(() => {});
        },
        // 多选操作
        handleSelectionChange(val) {
            this.multipleSelection = val;
        },
        delAllSelection() {
            const length = this.multipleSelection.length;
            let str = '';
            this.delList = this.delList.concat(this.multipleSelection);
            for (let i = 0; i < length; i++) {
                str += this.multipleSelection[i].name + ' ';
            }
            this.$message.error(`删除了${str}`);
            this.multipleSelection = [];
        },
        // 编辑操作
        handleEdit(index, row) {
            this.idx = index;
            this.form = row;
            this.editVisible = true;
        },
        // 保存编辑
        saveEdit() {
            this.editVisible = false;
            this.$message.success(`修改第 ${this.idx + 1} 行成功`);
            this.$set(this.tableData, this.idx, this.form);
        },
        // 分页导航
        handlePageChange(val) {
            console.log(val);
            this.$set(this.query, 'pageIndex', val);
            this.statisticRebateIncome();
        },
        // 分页导航
        activeCodeChange(val) {
            this.$set(this.activeCodeQuery, 'pageIndex', val);
            this.statisticActiveCodeSellIncome();
        },
        // 分页导航
        activeCodeRebateChange(val) {
            this.$set(this.activeCodeRebateQuery, 'pageIndex', val);
            this.statisticsActiveCodeRebateList();
        }
    }
};
</script>


<style scoped>
.handle-box {
    margin-bottom: 20px;
}

.handle-select {
    width: 120px;
}

.handle-input {
    width: 300px;
    display: inline-block;
}
.table {
    width: 100%;
    font-size: 14px;
}
.red {
    color: #ff0000;
}
.mr10 {
    margin-right: 10px;
}
.table-td-thumb {
    display: block;
    margin: auto;
    width: 40px;
    height: 40px;
}


.flexbox {
    display: -moz-box;
    display: -webkit-box;
    display: box;
    width: 100%
}
    .flex {
    -ms-flex: 1;
    flex: 1;
    -webkit-box-flex: 1;
    display: block;
    width: 100%
}
</style>
