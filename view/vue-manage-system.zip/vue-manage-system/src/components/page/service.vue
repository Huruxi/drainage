<template>
    <div>
        <div class="crumbs">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item>
                    <i class="el-icon-lx-calendar"></i> 联系客服
                </el-breadcrumb-item>
                <el-breadcrumb-item>联系方式</el-breadcrumb-item>
            </el-breadcrumb>
        </div>

        <div class="container">
            <div class="form-box">
                <el-form ref="form" :model="form" label-width="100px">
                    <el-form-item v-for="(v,index) in form.data" 
                    :label="v.name" 
                    :key="v.name"
                    :prop="'data.' + index + '.content'"
                    >
                        <el-input v-model="v.content"></el-input>
                    </el-form-item>
                    <el-form-item>
                        <el-button type="primary" @click="onSubmit('form')">提交</el-button>
                    </el-form-item>
                </el-form>    
            </div>
        </div>        
    </div>    
</template>

<script>

import { updateMerchantInfo,findMerchantInfo } from '../../api/merchant';
export default {
    data(){

        return {
            form:{
                data: [
                {
                    id: 0,
                    name: '客服名称',
                    content: '',
                },
                {
                    id: 0,
                    name: '客服电话',
                    content: '',
                },
                {
                    id: 0,
                    name: '客服微信号',
                    content: '',
                },
                {
                    id: 0,
                    name: '客服QQ号',
                    content: '',
                }
               ]
            }
        }
    },

    created() {
        this.getData();
    },

    methods: {
        getData(){
            findMerchantInfo({}).then(res => {
                 if(res.code == 200){
                     if(res.data.length > 0){
                        this.form.data = res.data;
                     }
                }
            });  
        },

        syncMerchantInfo(){
            updateMerchantInfo(this.form.data).then(res => {
                res = res.data;
                if(res.code == 200){
                    if(res.data){
                    this.form = res.data;
                    }
                    this.$message.success('提交成功');
                }
            }); 
        },

        onSubmit(formName){
            this.$refs[formName].validate((valid) => {
                if (valid) {
                    this.syncMerchantInfo();
                } else {
                    console.log('error submit!!');
                    return false;
                }
            });
        }
    }
}
</script>
